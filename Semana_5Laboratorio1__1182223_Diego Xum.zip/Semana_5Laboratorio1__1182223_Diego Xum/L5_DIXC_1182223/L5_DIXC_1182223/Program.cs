﻿using System.Security.Cryptography;

namespace L5_DIXC_1182223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                Console.WriteLine("Ingrese Valor");
                int numero; // EnvironmentVariableTarget tipo entero
                string entrada; //variable tipo cadena 

                Console.WriteLine("Ingrese un numero");
                entrada = Console.ReadLine();
                numero = Int32.Parse(entrada);

                if (numero >= 1 && numero <= 7)
                {
                    if (numero == 1)
                    {
                        Console.WriteLine("Lunes");
                    }
                    else if (numero == 2)
                    {
                        Console.WriteLine("Martes");
                    }
                    else if (numero == 3)
                    {
                        Console.WriteLine("Miercoles");
                    }
                    else if (numero == 4)
                    {
                        Console.WriteLine("Jueves");
                    }
                    else if (numero == 5)
                    {
                        Console.WriteLine("Viernes");
                    }
                    else if (numero == 6)
                    {
                        Console.WriteLine("Sabado");
                    }
                    else if (numero == 7)
                    {
                        Console.WriteLine("Domingo");
                    }
                }
                else if (numero >= 8)
                {
                    Console.WriteLine("Numero Invalido");
                }
                Console.ReadKey();
            }
        }
    }
    }
            

        