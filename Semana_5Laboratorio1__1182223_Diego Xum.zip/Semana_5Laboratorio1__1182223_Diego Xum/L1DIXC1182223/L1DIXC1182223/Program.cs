﻿//Console.WriteLine("Hola Mundo");
//Console.WriteLine("soy Diego");
//Console.WriteLine("Hola Munod");
//Console.Write("Soy Nombre");
//Console.ReadKey();

Console.WriteLine("Ingrese su Nombre");
string Nombre = Console.ReadLine();

Console.Write("Hola Mundo");
Console.Write("Soy" + Nombre);
Console.ReadKey();