﻿namespace L11_DIXC_1182223_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //// acumulador
            //double[] notas = new double[7];
            //double notas1;
            //double suma_de_notas = 0;
            //double notaMasAlta = 0;
            //// ingreso de notas
            //for (int i = 0; i < notas.Length; i++) 
            //{
            //    Console.WriteLine("Ingrese nota"+ i);
            //    notas1 = Convert.ToDouble(Console.ReadLine());

            //    notas[i] = notas1;
            //    //suma de las notas 
            //    suma_de_notas = suma_de_notas + notas1;
            //    // nota mas alta
            //    if (notas[i]> notaMasAlta) 
            //    {
            //    notaMasAlta = notas[i];
            //    }

            //}
            //double promedio = suma_de_notas / notas.Length;
            //Console.WriteLine("la suma de las notas es:" + suma_de_notas);
            //Console.WriteLine("EL Promedio de las notas de los ultimos 8 laboratorios es:" + promedio);
            //Console.WriteLine("La nota mas alta es:"+ notaMasAlta );


            // segunda parte frase 
            Console.WriteLine("Ingrese una palabra");
            string palabra = Console.ReadLine();

            Console.WriteLine("Ingresa una letra");
            char letra = char.Parse(Console.ReadLine());






        }




    }
}