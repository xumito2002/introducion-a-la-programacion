﻿using System.Diagnostics.CodeAnalysis;

namespace Proyecto_Dados
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Suma_de_Dados;
            string si;
            Console.WriteLine("Bienbenido al casino las Vegas Preparece para jugar");
            Console.WriteLine("Ingrese la cantidad de partidas");
            int candadeJuegos = int.Parse(Console.ReadLine());

            Console.WriteLine("Cuantas tiros por paritda desa realizar");
            int cantidad_de_tiros = int.Parse(Console.ReadLine());

            int puntos_del_Jugador = 0;
            int pundos_de_la_casa = 0;

            for (int partida1 = 1; partida1 <= candadeJuegos; partida1++)
            {
                Console.WriteLine("juego"+ "---->" +partida1);

                for(int tiro1 =1; tiro1 <= cantidad_de_tiros ;tiro1++ )
                {
                    Random random = new Random();
                    int dado1 = random.Next(1, 6);
                    Console.WriteLine("Dado_1 = " + dado1);
                    int dado2 = random.Next(1, 6);
                    Console.WriteLine("Dado_2 = " + dado2);
                    Suma_de_Dados  = dado1 + dado2;
                    Console.WriteLine("La suma de los dados es igual a:  " + Suma_de_Dados);
           
                    if (puntos_del_Jugador == 0)
                    {
                        if (Suma_de_Dados  == 6 || Suma_de_Dados  == 12)
                        {
                            puntos_del_Jugador += 12;
                            Console.WriteLine("El Jugador gana 12 puntos en el tiro 1");
                        }
                        else if (Suma_de_Dados == 4 || Suma_de_Dados  == 6 || Suma_de_Dados  == 10)
                        {
                            pundos_de_la_casa += 12;
                            Console.WriteLine("la casa gana 12 puntos en el primer tiro");
                        }
                        else if (Suma_de_Dados  == 2 || Suma_de_Dados  == 3 || Suma_de_Dados  == 5 || Suma_de_Dados  == 7 || Suma_de_Dados  == 8 || Suma_de_Dados  == 9)
                        {
                            puntos_del_Jugador = Suma_de_Dados;
                            Console.WriteLine("Los puntos del jugador son:" + Suma_de_Dados);
                        }
                    }
                    else
                    {
                        if (Suma_de_Dados == 11)
                        {
                            pundos_de_la_casa += 6;
                            Console.WriteLine("La casa gana 6 puntos");
                        }
                        else if (Suma_de_Dados == puntos_del_Jugador) 
                        {
                            puntos_del_Jugador += Suma_de_Dados;
                            Console.WriteLine("EL jugador gana" + Suma_de_Dados + "puntos");
                        }
                    
                    }
               
               }
              
            }

        }
    }
}