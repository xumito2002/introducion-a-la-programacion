﻿namespace Corto_N1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Corto#1");
            int numnero_mas_alto = 0;
           for(int i = 1; i < 7; i++) 
            {
                Console.WriteLine("Ingrese 7 numeros enteros");
                int numeros = Convert.ToInt32(Console.ReadLine());
                //numero mas alto
                int
            }
            
        }
    }
}