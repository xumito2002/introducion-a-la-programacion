﻿namespace T4_DIXC_1182223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tarea semana 7 formulas moviemto rectilino uniforme variado");
            Console.WriteLine("Instruciones:Ingrese los datos que se le solicita " +
                "colocar 0 al dato que desconosca");
            Console.WriteLine("Ingrese datos");
            Console.WriteLine(" ingrese Velocidad final");
            string numero1 = Console.ReadLine();
            int num1 = Convert.ToInt32(numero1);
            Console.WriteLine(" ingrese velocidad inicial");
            string numero2 = Console.ReadLine();
            int num2 = Convert.ToInt32(numero2);
            Console.WriteLine("ingrese aceleracion");
            string numero3 = Console.ReadLine();
            int num3 = Convert.ToInt32(numero3);
            Console.WriteLine("ingrese tiempo");
            string numero4 = Console.ReadLine();
            int num4 = Convert.ToInt32(numero4);
          

            // Ingresar "0" si en cuyo caso no se quiera agregar un valor a una variable

            if (num1 == 0 && num2 == 0 && num3 == 0 && num4 == 0)
            {
                Console.WriteLine("Error números incorrectos");
            }
            else if (num1 == 0)
            {
                Console.WriteLine(" Velocidad final es igual a  " + "=" + (num2+(num3*num4)) + "metros por segundo" );
            }
            else if (num2 == 0)
            {
                Console.WriteLine("Velocidad Inicial es igual a " + "=" + (num1-(num3*num4)) + " metros por segundos");
            }
            else if (num3 == 0)
            {
                Console.WriteLine(" aceleracion es igual a " + "=" + ((num1 - num2) / num4) + "metros por segundo cuadrado");
            }
            else if (num4 == 0)
            {
                Console.WriteLine(" tiempo es igual a " + "=" + ((num1 - num2) / num3) + "segundos");
            }


        }
    }
}