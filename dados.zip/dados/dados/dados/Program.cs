﻿using System.Timers;

namespace dados
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("    _______  _______  _______  ___   __    _  _______    ___      _______  _______    __   __  _______  _______  _______  _______\r\n   |       ||   _   ||       ||   | |  |  | ||       |  |   |    |   _   ||       |  |  | |  ||       ||       ||   _   ||       |\r\n   |       ||  |_|  ||  _____||   | |   |_| ||   _   |  |   |    |  |_|  ||  _____|  |  |_|  ||    ___||    ___||  |_|  ||  _____|\r\n   |       ||       || |_____ |   | |       ||  | |  |  |   |    |       || |_____   |       ||   |___ |   | __ |       || |_____\r\n   |      _||       ||_____  ||   | |  _    ||  |_|  |  |   |___ |       ||_____  |  |       ||    ___||   ||  ||       ||_____  |\r\n   |     |_ |   _   | _____| ||   | | | |   ||       |  |       ||   _   | _____| |   |     | |   |___ |   |_| ||   _   | _____| |\r\n   |_______||__| |__||_______||___| |_|  |__||_______|  |_______||__| |__||_______|    |___|  |_______||_______||__| |__||_______|\r\n  ");
                                    Console.WriteLine("____________________-███▓▒░░.Bienvenido A Casino Las Vegas.░░▒▓███___________________");
            Console.WriteLine();
            //Ingreso de datos para el juego 
            Console.Write("Ingrese la cantidad de partidas: ");
            int numeroDePartidas = Convert.ToInt32(Console.ReadLine());
           Console.WriteLine();
            Console.Write("Ingrese la cantidad de tiros por partida : ");
            int tirosPorPartida = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Ingrese Nombre del Jugador");
            string nombre = Console.ReadLine();

            int partidas_ganadas_jugador_1 = 0;
            int partidas_ganadas_jugador2 = 0;
            int partidas_enpatadas = 0;
            int tiros_Pares = 0;
            int tiros_Impares = 0;
            int puntosPorTiro = 0;
            Random random = new Random();

            for (int partida = 1; partida <= numeroDePartidas; partida++)
            {
                Console.WriteLine("-------------`•.¸¸.•´´¯`••._.•(Partida"+partida +" )•.¸¸.•´´¯`••._.• --------------");

                int totalJugador1 = 0;
                int total_de_casa = 0;
                int tiro_especial_jugador = 0;
                int tiro_especial_casa = 0;
                int tiro_piertede_jugador = 0;
                int sumatoriaDados = 0;
              

                for (int tiro = 1; tiro <= tirosPorPartida; tiro++)
                {

                        // tiro del primer jugador 
                        Console.WriteLine( "------------------ Tiro"+tiro+"---------------------");
                    
                    int dado1 = random.Next(1,7);
                    int dado2 = random.Next(1,7);
                     sumatoriaDados = dado1 + dado2;
                    puntosPorTiro = sumatoriaDados;
                    if (dado1  % 2 == 0)
                    {
                        tiros_Pares++;
                    }
                    else
                    {
                        tiros_Impares++;
                    }
                    if (dado2 % 2 == 0)
                    {
                        tiros_Pares++;
                    }
                    else
                    {
                        tiros_Impares++;
                    }
                    Console.WriteLine(nombre +": Dado 1: " + dado1 + " Dado 2: " + dado2 + " Sumatoria:  " + sumatoriaDados + " Puntos por tiro: " + puntosPorTiro);

                    
                    if (tiro == 1 && (sumatoriaDados == 11))
                    {
                        Console.WriteLine("el jugador " + nombre + " pierde la partida");
                        puntosPorTiro = 0;
                        total_de_casa += 6;
                        Console.WriteLine("la casa gana " + total_de_casa + "puntos");
                        break; // rompe el bucle y continua el juego
                    }
                    if (tiro == 1 && (sumatoriaDados == 12 || sumatoriaDados == 6))
                    {
                        tiro_especial_jugador = totalJugador1;
                        //el jugador gana 12 puntos pos sacar 12 en wwl primer tiro
                        totalJugador1 += 12; 
                        Console.WriteLine(nombre +" gana 12 puntos en el primer turno");
                    }
                    else
                    {
                        totalJugador1 += puntosPorTiro;
                    }
                    
                    // tiro de casa 
                    dado1 = random.Next(1,7);
                    dado2 = random.Next(1,7);
                    sumatoriaDados = dado1 + dado2;
                    puntosPorTiro = sumatoriaDados;
                    if (dado1  % 2 == 0)
                    {
                        tiros_Pares++;
                    }
                    else
                    {
                        tiros_Impares++;
                    }
                    if (dado2 % 2 == 0)
                    {
                        tiros_Pares++;
                    }
                    else
                    {
                        tiros_Impares++;
                    }
                    Console.WriteLine(" Casa: Dado 1: "+dado1+", Dado 2: "+dado2+", Sumatoria: "+sumatoriaDados+", Puntos por tiro: "+ puntosPorTiro);
                    
                    if (tiro ==1 && (sumatoriaDados== 11)) 
                    {
                        Console.WriteLine("La casa pierde la partida");
                        puntosPorTiro = 0 ;
                        totalJugador1 =0+6   ;
                        Console.WriteLine("EL jugador"+nombre + "gana " +totalJugador1 + "puntos");
                        break; // se rompe el bucle en este el jugador gana 6 puntos y la partida 
                    }
                   //tiro especial de la casa 
                    if (tiro == 1 &&(sumatoriaDados==4||sumatoriaDados ==10) ) 
                    {
                        tiro_especial_casa = total_de_casa;
                        total_de_casa += 12;
                        Console.WriteLine("Lacasa gana 12 puntos");
                    }
                    else 
                    {
                    total_de_casa  += puntosPorTiro  ;
                    }

                }
                    // imprecion final
                   Console.WriteLine("Puntos de la Partida:"+partida+" "  + nombre +":" +totalJugador1+"punto"+  " Casa:" + total_de_casa+"puntos");
                   Console.WriteLine();
                  
                    
                    if (totalJugador1 > total_de_casa)
                    {
                    partidas_ganadas_jugador_1++;
                        Console.WriteLine(nombre +"gana la partida");
                    
                    }
                    else if (totalJugador1 < total_de_casa)
                    {
                    partidas_ganadas_jugador2++;
                        Console.WriteLine("La casa gana la partida");
                    }
                    else
                    {
                    partidas_enpatadas++;
                    Console.WriteLine("¡La partida es un empate!");

                    }Console.WriteLine();

            }
            Console.WriteLine("________________________Resumen de los juegos ganados y Enpatadas____________________________");
            Console.WriteLine("Partidas ganadas por el jugador:" + nombre+" " +partidas_ganadas_jugador_1 +  " Partidas ganadas");
            Console.WriteLine("Partidas ganadas por la casa: "+ partidas_ganadas_jugador2 + " Partidas Ganadas " );
            Console.WriteLine("Partidas Enpatadas:  " + partidas_enpatadas);
            Console.WriteLine("El total de tiros pares de" + tiros_Pares +"tiros");
            Console.WriteLine("El total de tiro inpares es de :" + tiros_Impares  + "tiros");




            Console.WriteLine("  _    _    _    _    _    _    _     _    _    _     _    _    _    _    _\r\n / \\  / \\  / \\  / \\  / \\  / \\  / \\   / \\  / \\  / \\   / \\  / \\  / \\  / \\  / \\\r\n( G )( r )( a )( c )( i )( a )( s ) ( p )( o )( r ) ( J )( u )( g )( a )( r )\r\n \\_/  \\_/  \\_/  \\_/  \\_/  \\_/  \\_/   \\_/  \\_/  \\_/   \\_/  \\_/  \\_/  \\_/  \\_/\r\n");


        }      
    }

}
   