﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoL9_DIXC_1182223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //    Console.WriteLine("Semana 9 - Repeticiones");
            //    int N = 6;
            //    int M = 8;
            //    while (M < N)
            //    {
            //        Console.WriteLine("Num:" + M.ToString());
            //        M++;
            //    }
            //    Console.WriteLine();

            //Console.WriteLine("Ingrese un numero");
            //int numero = Convert.ToInt32((Console.ReadLine()));
            //int contador = 1;
            //int sumatoria = 0;
            //string cadena = "";
            //while (contador <= numero)
            //{
            //    sumatoria = sumatoria + contador;
            //    cadena = cadena + contador + "+";
            //        contador++;
            //}
            //Console.WriteLine("La suma de los numero es " +sumatoria );
            //Console.WriteLine(cadena + "=" + sumatoria  );


            Console.WriteLine("Tablas de Multiplicacion");
            Console.WriteLine("Ingrese un numero para iniciar la tabla ");
            int numero = Convert.ToInt32((Console.ReadLine()));

            Console.WriteLine("Tabla de multiplicacion de 1 " + numero);

            for (int i = 1; i <= 10; i++)
            {
                int resultado = numero * i;
                Console.WriteLine(numero + "x" + i + "=" + resultado);
            }




        }
    }
}